Welcome to the data package for the project �FL Studio Tutorials on Youtube� by Group 15.This package is structured in three subfolders; data, src and docs.The 'data' folder contains the raw data that is collected through the API.The script for the API itself can be found in the �src� folder.Documentation with relevant information can be found in the �docs� folder.

The documentation for this project can be found in the document 'Group15resit_DatasheetsforDataSets.pdf'

Throughout the documentation, the word 'Snippet' is used. A snippet is a brief extract from an instance and within YouTube this extract exists of video descriptions, thumbnails and other non-statistical datapoints. 

On the basis of feedback provided by lecturer Hannes Datta, this project was improved by Quinten de Putter and Jeroen Maagdenberg for a second submission.