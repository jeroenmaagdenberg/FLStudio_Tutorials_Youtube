Welcome to the data package for the project �FL Studio Tutorials on Youtube�.This package is structured in three subfolders; data, src and docs.The 'data' folder contains the raw data that is collected through the API.The script for the API itself can be found in the �src� folder.A document with relevant links can be found in the �docs� folder.

The documentation for this project can be found in the document 'Group 15 - DatasheetsforDataSets.pdf'

Throughout the documentation, the word 'Snippet' is used. A snippet is a brief extract from an instance and within YouTube this extract exists of video descriptions, thumbnails and other non-statistical datapoints. 